package o1.flappy

import o1._

class Game {

  // Your code goes here. 
  val bug = new Bug(new Pos(BugX, BugY))
  //val bug = new Bug(new Pos(100, 40))
  private val obs1 = new Obstacle(70)
  private val obs2 = new Obstacle(30)
  private val obs3 = new Obstacle(20)
  val obstacles = Vector(obs1, obs2, obs3)
  
  def timePasses() = {
    bug.fall()
//    for (current <- obstacles) {
//      current.approach
//    }
    obstacles.foreach(n => n.approach)
  }
  
  def activateBug() = {
    bug.flap(FlapStrength)
    //bug.flap(15)
  }
  
  def isLost = {
/*    var osuiko = false
    for (current <- obstacles) {
      if (current.touches(this.bug) || !this.bug.isInBounds) {
        osuiko = true
      }
    }
    osuiko */
  obstacles.exists(_.touches(this.bug) || !this.bug.isInBounds)  
  } 
  
}
