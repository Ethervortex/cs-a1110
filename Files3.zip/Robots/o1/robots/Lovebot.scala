package o1.robots

import o1._
import scala.math._

class Lovebot(name: String, body: RobotBody, val beloved: RobotBody) extends RobotBrain(name, body) {
  private val directions = Vector[CompassDir](North, East, South, West)
  
  private def calcDist: (Int, Int) = {
    var belovedLoc: GridPos = beloved.location
    var ownLoc: GridPos = this.body.location
    var x = ownLoc.xDiff(belovedLoc)
    var y = ownLoc.yDiff(belovedLoc)
    
    (x, y)
  }
  
  private def suunta: CompassDir = {
      if(abs(calcDist._1) >= abs(calcDist._2)) {
        if(calcDist._1 > 0)
          East
        else
          West
      }   
      else {
        if(calcDist._2 > 0)
          South
        else
          North
      }
  }
  
  def moveBody() = {
    if((abs(calcDist._1) == 1 && abs(calcDist._2) == 1) || abs(calcDist._1) > 1 || abs(calcDist._2) > 1) {
      if(this.body.neighboringSquare(suunta).robot == None) {
        body.spinTowards(suunta)
        this.body.moveTowards(suunta)
      }
      else {
        body.spinTowards(suunta)
        this.body.neighboringSquare(suunta).robot.foreach(_.destroy)
      }
    }
  }
}


