package o1.blood


class BloodType(val abo: String, val rhesus: Boolean) {
  

  override def toString = this.abo + (if (this.rhesus) "+" else "-")
  

  def hasSafeABOFor(recipient: BloodType) = {
    if (this.abo == "A" && (recipient.abo == "A" || recipient.abo == "AB"))
      true
    else if (this.abo == "B" && (recipient.abo == "B" || recipient.abo == "AB"))
      true
    else if (this.abo == "O" && (recipient.abo == "A" || recipient.abo == "B" || recipient.abo == "AB" || recipient.abo == "O"))
      true
    else if (this.abo == "AB" && recipient.abo == "AB")
      true
    else
      false
  }
   

  def hasSafeRhesusFor(recipient: BloodType) = {
    if (!this.rhesus)
      true
    else if (this.rhesus && recipient.rhesus)
      true
    else
      false
  }
  
  
  def canDonateTo(recipient: BloodType) = {
    if (this.hasSafeABOFor(recipient) && this.hasSafeRhesusFor(recipient))
      true
    else
      false
  }
  
  
  def canReceiveFrom(donor: BloodType) = {
    donor.canDonateTo(this)
  }
    
}

