package o1
object misc { // These definitions at the top are discussed in Chapter 4.5.

  // Various small assignments across several chapters will ask you to define functions in this file.
  // Please enter your code below this comment.
  
  def together(vektori: Vector[String], tempo: Int) = {
    val vektoristring = vektori.mkString("&")
    
    vektoristring + "/" + tempo.toString
  }

  def tempo(nuotit: String) = {
    var merkkijono = nuotit.takeRight(11)
    var i = 0
    
    while (i < 11) {
      if (merkkijono.head.toString == "/") {
        merkkijono = merkkijono.tail
        i = 11
         
      }
      else {
        merkkijono = merkkijono.tail
        i = i + 1
        if (i == 10 && merkkijono.head.toString != "/") {
          merkkijono = "120"
          i = 11
        }
      }     
    }
    merkkijono.toInt
  }

  def toMinsAndSecs(sekunnit: Int) = {
    var pari = (sekunnit / 60, sekunnit % 60)
    pari
  }
  
  def isAscending(lukuVektori: Vector[Int]) = {
    lukuVektori.zip(lukuVektori.tail).forall(isInOrder(_))
  }
  
  def isInOrder(pairOfNumbers: (Int, Int)) = pairOfNumbers._1 <= pairOfNumbers._2    // This example function is introduced in Chapter 8.4. You can ignore it until then.
  
}