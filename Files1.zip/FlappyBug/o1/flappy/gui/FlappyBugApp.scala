package o1.flappy.gui

import o1._
import o1.flappy._

// This class is introduced in Chapter 2.7.

object FlappyBugApp extends App {

  val sky        = rectangle(ViewWidth, ViewHeight,  LightBlue)
  val ground     = rectangle(ViewWidth, GroundDepth, SandyBrown)
  val trunk      = rectangle(30, 250, SaddleBrown)
  val foliage    = circle(200, ForestGreen) 
  val tree       = trunk.onto(foliage, TopCenter, Center)
  val rootedTree = tree.onto(ground, BottomCenter, new Pos(ViewWidth / 2, 30))
  val scenery    = sky.place(rootedTree, BottomLeft, BottomLeft)

  
  val bugPic = Pic("ladybug.png")


  //def rockPic(obstacle: Obstacle) = circle(obstacle.radius * 2, Black)

  def rockPic(obstacle: Obstacle) = Pic("obstacle.png").scaleTo(obstacle.radius * 2)
  
  // INSERT YOUR OWN CODE BELOW.
  
  val malli = new Game
  
  val gui = new View(malli, "FlappyBug") {
    var background = scenery
    
    def makePic = {
 /*     var kokooja: Pic = background
      for (current <- malli.obstacles) {
        kokooja = kokooja.place(rockPic(current), current.pos)
      } 
      kokooja.place(bugPic, malli.bug.pos) */
      //background.place(bugPic, malli.bug.pos).place(rockPic(malli.obstacles), malli.obstacles.pos)
      malli.obstacles.foldLeft(background)((background, n) => background.place(rockPic(n), n.pos)).place(bugPic, malli.bug.pos)  
    }
    
 /*   def makePic = {
      background.place(bugPic, malli.bug.pos).place(rockPic(malli.obstacle), malli.obstacle.pos)
    }*/
    
    override def onKeyDown(painettu: Key) = {
      if (painettu == Key.Space)
        malli.activateBug()
    }
    
    override def onTick() = {
      malli.timePasses
      this.background = this.background.shiftLeft(BackgroundShift)
      //this.background = this.background.shiftLeft(2)
    }
    
    override def isDone = malli.isLost
  }
  
  gui.start()
}

