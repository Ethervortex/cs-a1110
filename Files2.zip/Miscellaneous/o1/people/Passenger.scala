package o1.people

class Passenger(val name: String, val card: Option[TravelCard]) {
  
  def canTravel = {
    if (this.card.isDefined) {
      this.card match {
        case Some(kortti) => kortti.isValid
        case None => false
      }
    }
    else
      false 
  }
      
  def hasCard = {
    this.card.isDefined
    
  }
}