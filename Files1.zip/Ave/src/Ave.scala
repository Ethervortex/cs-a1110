object Ave extends App {
  println("Ave, Munde!")
  println("No avepa ave sinnekin!")
}
