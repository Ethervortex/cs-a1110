package o1.looptest

// This example is discussed in Chapter 5.4.

object Example1 extends App {

  for (character <- "llama") {
    println("Letter: " + character)
  }
  
}

