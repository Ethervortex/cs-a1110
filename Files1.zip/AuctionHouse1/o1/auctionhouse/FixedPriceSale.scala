package o1.auctionhouse

class FixedPriceSale(val description: String, val price: Int, duration: Int) {
  
  private var dur = this.duration
  private var ostaja: Option[String] = None
  
  def daysLeft: Int = this.dur
  
  override def toString = this.description
  
  def buyer: Option[String] = {
    if (isOpen)
      None
    else
      this.ostaja
  }
  
  def isExpired: Boolean = {
    this.dur == 0
  }
  
  def isOpen: Boolean = {
    this.ostaja match {
      case None => !this.isExpired
      case Some(jokuOstaja) => false
    }
  }
  
  def advanceOneDay(): Unit = {
    if (!this.isExpired && this.isOpen)
      this.dur -= 1
  }
  
  def buy(buyer: String): Boolean = {
    if (this.isOpen) {
      this.ostaja = Some(buyer)
      true
    }
    else
      false
    
  }
  
  
}