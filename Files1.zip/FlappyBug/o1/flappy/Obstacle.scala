package o1.flappy

import o1._
import scala.util.Random

// This class is introduced in Chapter 2.4.

class Obstacle(val radius: Int/*, initialPos: Pos*/) { 
  
  private var currentPos = this.randomLaunchPosition()
  
  def pos = this.currentPos
  
  def approach() = {
    if (isActive)
      this.currentPos = this.currentPos.addX(-ObstacleSpeed)
    else {
      this.currentPos = this.randomLaunchPosition()
      //this.currentPos = this.currentPos.vectorTo(this.randomLaunchPosition())
      //this.currentPos = this.currentPos.setY(ViewHeight/2) vanhin
    }
  }
  
  def touches(otokka: Bug) = {
    this.currentPos.distance(otokka.pos) < (BugRadius + this.radius)
  }
  
  private def randomLaunchPosition() = {
    val launchX = ViewWidth + this.radius + Random.nextInt(500) //Laske yhteen ruudun leveys (1000), esteen säde ja satunnainen kokonaisluku väliltä 0--499.
    val launchY = Random.nextInt(400) //Arvo satunnainen kokonaisluku, joka on vähintään 0 ja pienempi kuin ruudun korkeus (400).
    new Pos(launchX, launchY)
}
  
  def isActive = if (this.currentPos.x >= -this.radius) true else false

  override def toString = "center at " + this.pos + ", radius " + this.radius
    
}
