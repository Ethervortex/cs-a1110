package o1.robots

import o1._

class  Psychobot(name: String, body: RobotBody) extends RobotBrain(name, body) {
  private val directions = Vector[CompassDir](North, East, South, West)
  private var ownLoc: GridPos = this.body.location
  private var vihuLoc: GridPos = this.body.location
  
  private def scan: Option[GridPos] = {  
    //var lopeta = false
    
    for(current <- directions) { // käy suunnat läpi
      var inputs = ownLoc.pathTowards(current).takeWhile(n => (body.world(n) != Wall)) // || (body.world.elementAt(n).robot.exists(_.isBroken == true) ))
      inputs = inputs.filter(n => body.world(n).robot != None) // || body.world(n).robot.exists(_.isBroken) )
      inputs = suodata(inputs)
      
      //println(inputs)
      
      if(!inputs.isEmpty) {
        body.spinTowards(current)
        return Some(inputs(0))
      }
    }
    
    return None
  }
  
  private def suodata(inputs: Stream[GridPos]) = { // jos eka robo rikki, poista kaikki
    var laskuri = 1
    var suodatettu = inputs
    
    for(current <- inputs) {
      body.world(current).robot match {
        case Some(bot) => if(bot.isBroken == true && laskuri == 1) {
          suodatettu = suodatettu.drop(suodatettu.size)
        } 
        else {
          laskuri += 1 //suodatettu = suodatettu.take(1) else { suodatettu = suodatettu.drop(laskuri); laskuri += 1}
        }
        case None => None
      }
    }
    suodatettu
  }
  
  def moveBody() = {
    vihuLoc = scan match {
      case Some(pos) => pos
      case None => this.body.location
    }
    while(ownLoc.distance(vihuLoc) > 1) {
      body.moveTowards(body.facing)
      ownLoc = this.body.location
    }
    this.body.neighboringSquare(body.facing).robot.foreach(_.destroy)
    //println(ownLoc)
    //println(vihuLoc)   
  }
}


