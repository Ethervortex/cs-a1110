package o1.shapes

import scala.math._

class RightTriangle(val x: Double, val y: Double) extends Shape {
  
  def area = this.x * this.y /2
  
  def hypotenuse = sqrt((this.x * this.x) + (this.y * this.y))
  
  def perimeter = this.x + this.y + this.hypotenuse
  
}