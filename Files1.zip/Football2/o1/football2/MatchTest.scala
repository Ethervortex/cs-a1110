package o1.football2
import o1.football2.ExampleLeague._
    
/** A small program that uses the classes `Club` and `Match` to keep track 
  * of some football matches. To be customized by the student. */
object MatchTest extends App {

  val h1 = new Player("P Cech", CHE)
  val h2 = new Player("M Schwarzer", CHE)
  val h3 = new Player("C Azpilicueta", CHE)
  val h4 = new Player("A Col", CHE)
  
  val a1 = new Player("L Price", CP)
  val a2 = new Player("W Hennessey", CP)
  val a3 = new Player("J Speroni", CP)
  val a4 = new Player("D Moxey", CP)
  
  

  // Create a new match, add some goals and print out some stats.
  val match1 = new Match(CHE, CP)
  match1.addGoal(h1)
  match1.addGoal(a1)
  match1.addGoal(a1)
  match1.addGoal(a2)
  match1.addGoal(h2)
  //println(match1.homeGoals)
  //println(match1.awayGoals)
  //println(match1.goalDifference)

  // Add some more goals to the same match and print out more stats:
  match1.addGoal(h4)
  match1.addGoal(h3)
  
  //match1.addGoal(a4)
  
  println(match1.totalGoals)
  println(match1.goalDifference)
  
  if (match1.isHomeWin)
    println(match1.home.name + " is winner.")

  // Create another match:
  val match2 = new Match(CP, CHE)
  // Print out the goals scored by each club in the second match: 
  println(match2.homeGoals)
  println(match2.awayGoals)
  
  // Test which match has the larger total score:
  println(match2.isHigherScoringThan(match1))
  println(match1.isHigherScoringThan(match2))

  // Check goallessness:
  if (match1.isGoalless) {
    println("The first match is goalless.") 
  }
  if (match2.isGoalless) {
    println("The second match is goalless.") 
  }

  // Print out the locations:
  //println(match1.location)
  //println(match2.location)

  // Print out full descriptions of the matches:
  //println(match1)
  //println(match2)

  // You'll need to expand this program in order to test all the features
  // of the classes properly.
  //println(match1.isHomeWin)
  //println(match2.isHomeWin)
  
  println(match1.location)
  println(match2.location)
  
  println(match1.hasScorer(h2))
  println(match2.hasScorer(h2))
  
  println(match1.winningScorerName)
  println(match2.winningScorerName)
}
