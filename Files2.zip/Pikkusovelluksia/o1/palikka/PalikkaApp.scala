package o1.palikka

import o1._

// Tämä ohjelma liittyy lukuun 2.7 ja on esitelty siellä. 

object PalikkaApp extends App {
  
  val malli = new Palikka(20, new Pos(300, 50), Gray)
 
  val nakyma = new View(malli) {
    def makePic = {
      val tausta = rectangle(500, 500, Black) 
      val palikanKuva = rectangle(malli.koko, malli.koko, malli.vari)
      tausta.place(palikanKuva, malli.sijainti)
    }
  }

  nakyma.start()

}