package o1.time

/** A small program that uses the classes `Moment` and `Interval`
  * in some way decided by the student. */
object TimeTest extends App {
  // Insert some test code here.
}