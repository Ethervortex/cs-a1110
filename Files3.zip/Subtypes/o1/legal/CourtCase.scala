package o1.legal

class CourtCase(val plaintiff: Entity, val defendant: Entity) {
  
  override def toString = this.plaintiff.name + " v. " + this.defendant.name
  
}

