package o1.football2

import scala.collection.mutable.Buffer


/** The class `Match` represents match results in a football match statistics program. 
  * A match is played between teams from two clubs: a home club and an away club. 
  * Goals scored by players of either team can be added to the match object with the 
  * method `addGoal`.
  *
  * The class is expected to be used so that a match object with no goals is initially 
  * created as a real-life match starts. Goals are added incrementally as the match 
  * progresses. (A match object has mutable state.)
  *
  * @param home  the club whose team plays at home in the match
  * @param away  the club whose team plays away in the match */
class Match(val home: Club, val away: Club) {

  private val homeScorers = Buffer[Player]()    // container: goalscorers of the home team are added here
  private val awayScorers = Buffer[Player]()    // container: goalscorers of the away team are added here

  private val homeScorerNames = Buffer[String]()
  private val awayScorerNames = Buffer[String]()
  
  def winnerName = { 
    if (this.goalDifference < 0)
      this.away.name
    else if (this.goalDifference > 0)
      this.home.name
    else  
      "no winner" 
  }

  def winningScorerName = {

    if (isHomeWin) {
      this.homeScorerNames(this.awayScorerNames.size).toString
    }
    else if (isAwayWin) {
      this.awayScorerNames(this.homeScorerNames.size).toString
    }
    else {
      "no winning goal"
    }
  }
    
  def addGoal(scorer: Player): Unit = {
    if (scorer.employer == this.home) {
      this.homeScorers += scorer
      this.homeScorerNames += scorer.name
    } 
    // TODO: not complete yet!
    else {
      this.awayScorers += scorer
      this.awayScorerNames += scorer.name
    }
  }
  
  def allScorers = this.homeScorers.toVector ++ this.awayScorers.toVector
    
    
  def hasScorer(possibleScorer: Player) = this.allScorers.contains(possibleScorer)
  
  
    
  def homeGoals = this.homeScorers.size
  
  def awayGoals = this.awayScorers.size  
  
  def totalGoals = this.homeScorers.size + this.awayScorers.size
  
  def isGoalless = if (this.totalGoals > 0) false else true
  
  def isHomeWin = if (this.homeGoals > this.awayGoals) true else false
  
  def isAwayWin = if (this.homeGoals < this.awayGoals) true else false
  
  def isTied = this.homeGoals == this.awayGoals
  
  def location = this.home.stadium
  
  def isHigherScoringThan(anotherMatch: Match) = this.totalGoals > anotherMatch.totalGoals
  
  def goalDifference = this.homeGoals - this.awayGoals
  
  
  
  override def toString = {
    //this.home + " vs. " + this.away + " at " + this.home.stadium + ": " +
    
    if (this.isGoalless) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + "tied at nil-nil"
    }
    else if (this.isTied && !this.isGoalless) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + "tied at " + this.homeGoals + "-all"
    }
    else if (this.isHomeWin) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + this.homeGoals + "-" + this.awayGoals + " to " + this.home.name
    }
    else /*if (this.isAwayWin)*/ {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + this.awayGoals + "-" + this.homeGoals + " to " + this.away.name
    }

  }
}

  
  
