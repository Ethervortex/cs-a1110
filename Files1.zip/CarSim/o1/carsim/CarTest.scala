package o1.carsim

import o1.Pos

/** A small program that uses the class `Car`. Students are free eto extend and customize it. */
object CarTest extends App {
  
  private def printReport(car: Car) = {
    println(s"Now at "      + car.location)
    println(s"Fuel ratio: " + car.fuelRatio    + "%")
    println(s"Fuel range: " + car.fuelRange    +" m")
    println(s"Driven: "     + car.metersDriven + " m")
    
    
  }
  
  val testCar = new Car(9.26, 63.39, 29.60, new Pos(5.88, 47.13)) // using (weird) round figures for simplicity
  println("Car created.")
  printReport(testCar)
  
  println(s"\nAdding 88.95 liters.")
  //testCar.fuel(88.95) 
  printReport(testCar)
  println(s"Fuel: " + testCar.fuel(88.95))
  
  val testCar2 = new Car(11.07, 72.9, 27.92, new Pos(-49.62, -26.2))
  println(s"\nCar2 created.")
  printReport(testCar2)
  
  println(s"\nAdding 5 liters.")
  //testCar2.fuel(5) 
  printReport(testCar2)
  println(s"Fuel: " + testCar2.fuel(5))
  
  println(s"\nDriving car1.")
  // This 1000 km drive drains all the fuel, which is only enough for 40% of the trip. Should end up at (-140.0,180.0).
  testCar.drive(new Pos(-200, 150), 300000)
  printReport(testCar)
  
  
  
  //println(s"\nDriving car2.")
  //testCar2.drive(new Pos(0, -26.2), 1610028) 
  //printReport(testCar2)
  // Modify the above and/or add your own test code here, if you wish.
  

}
