package o1.takiainen

import o1._

object Takiaisohjelma3 extends App {

  
}