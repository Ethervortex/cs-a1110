package o1.people

class Member(val id: Int, val name: String, val yearOfBirth: Int, val yearOfDeath: Option[Int]) {   

  // TODO: missing methods
  def isAlive = {
    yearOfDeath == None
  }
  
  override def toString = {
    
    this.name + "(" + this.yearOfBirth + "-" + this.yearOfDeath.getOrElse("") + ")"
    
  }
  
}
