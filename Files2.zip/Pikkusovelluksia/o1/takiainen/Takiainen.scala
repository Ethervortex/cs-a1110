package o1.takiainen

import o1.Pos

// Tämä luokka liittyy lukuun 2.8 ja on esitelty siellä. 

class Takiainen {
  var sijainti = new Pos(0, 0)  // tuoreimman säilyttäjä
}

