package o1.robots.tribal


class Stack[Element] {
  private var lista = List[Element]()
  
  def push(newFrame: Element): Unit = {
    lista = newFrame :: lista
  }
  
  def pop(): Option[Element] = {
    var eka = lista.lift(0)
    lista = lista.tail
    eka
  }
  
  def peek: Option[Element] = {
    lista.lift(0)
  }
  
  def size = lista.size // TODO: implement this properly
  
  override def toString = "A stack of size " + this.size 
  
}


