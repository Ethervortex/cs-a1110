package o1

package object rainfall {

  // What goes here is described in Chapter 6.3.  
  def averageRainfall(mittaus: Vector[Int]) = {
    //var jakso: Option[Int] = None
    var suodatettu = mittaus.takeWhile( _ != 999999).filter( _ >= 0 )
    var jakso = 
      if(suodatettu.isEmpty) 
        None 
      else 
        Some(suodatettu.foldLeft(0)( _ + _ ) / suodatettu.length)
   
    jakso     
  }
  
  def drySpell(mittaus: Vector[Int], length: Int) = {
    //var indeksi = mittaus.indexWhere(n => n <= 5 && n >= 0 ) 
    var laskuri = 0
    var index = -1
    for (x <- mittaus.sliding(length)) {
      if ((x.forall(n => n >= 0 && n <= 5)) && (index == -1)) {
        index = laskuri
        laskuri += 1
      }
      else {   
        laskuri += 1      
      }
    }
    index
  }
}