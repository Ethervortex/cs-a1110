package o1.football3

import scala.collection.mutable.Buffer
import scala.math._

class Season() {
  
  private val results = Buffer[Match]()
  private var isoinVoitto: Option[Match] = None
  private var i = 0
  
  def addResult(newResult: Match): Unit = {
    
    this.results += newResult
    i = i + 1
    this.isoinVoitto match {
      case None => 
        this.isoinVoitto = Some(newResult)
      case Some(oldBiggest) =>
        val newBiggest = if(abs(newResult.goalDifference) > abs(oldBiggest.goalDifference)) newResult else oldBiggest
        this.isoinVoitto = Some(newBiggest)
    }    
  }
  
  def biggestWin: Option[Match] = {
    
    this.isoinVoitto
    
  }
  
  def latestMatch: Option[Match] = {
    if (i == 0)
      None
    else  
      Some(this.results(i-1))
  }
  
  def matchNumber(number: Int): Option[Match] = {
    if (i == 0 || (number + 1) > i || number < 0)
      None
    else
      Some(this.results(number))
  }
  
  def numberOfMatches: Int = {
    results.size
  }
  
  
}