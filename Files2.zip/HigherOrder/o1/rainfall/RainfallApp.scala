package o1.rainfall

import scala.io.StdIn._

object RainfallApp extends App {

  // Enter your program here as instructed in Chapter 7.1.
  def requestInput(): Int = {
    readLine("Enter rainfall (or 999999 to stop): ").toInt
  }
  
  def analyze(mittaus: Stream[Int]) = {
    var jakso = 
      if(mittaus.isEmpty) 
        println("No valid data. Cannot compute average.")
      else {
        println("The average is " + (mittaus.foldLeft(0)( _ + _ ) / mittaus.length))
      }
  }
  
  var rain = Stream.continually(requestInput()).takeWhile( _ != 999999).filter( _ >= 0 )
  analyze(rain)
  //rain.takeWhile( _ != 999999).filter( _ >= 0 )
}