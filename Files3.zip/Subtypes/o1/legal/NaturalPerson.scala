package o1.legal



// TODO: define classes NaturalPerson, FullCapacityPerson, and ReducedCapacityPerson

abstract class NaturalPerson(val personID: String, name: String) extends Entity(name) {
  
  def kind = "human"
    
}

class FullCapacityPerson(personID: String, name: String) extends NaturalPerson(personID, name) {
  def contact: FullCapacityPerson = new FullCapacityPerson(personID, name)
  
  override def kind = super.kind + " in full capacity"
}

class ReducedCapacityPerson(personID: String, name: String, val restriction: Restriction, val guardian: FullCapacityPerson) extends NaturalPerson(personID, name) {
  def contact: FullCapacityPerson = guardian
  override def kind = super.kind + " with " + this.restriction
}