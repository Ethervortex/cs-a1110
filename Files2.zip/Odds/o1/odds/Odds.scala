package o1.odds

// This class is gradually developed between Chapters 2.4 and 3.3.

class Odds(val wont: Int, val will: Int) {
  
  def probability = 1.0 * this.will / (this.wont + this.will)
  
  def fractional = this.wont + "/" + this.will
  
  def decimal = 1.0 * (this.wont + this.will) / this.will
  
  def winnings(voitot: Double) = voitot * decimal
  
  def not = new Odds(this.will, this.wont)
  
  override def toString = this.fractional
  
  def both(toiset: Odds) = new Odds(this.wont * toiset.wont + this.wont * toiset.will + this.will * toiset.wont, this.will * toiset.will)
  
  def either(toiset: Odds) = new Odds(this.wont * toiset.wont, this.wont * toiset.will + this.will * toiset.wont + this.will * toiset.will)
  
  def isLikely = this.probability > 0.5
  
  def isLikelierThan(toinen: Odds) = this.probability > toinen.probability
  
  def moneyline =
    if (this.wont >= this.will)
      100 * this.wont / this.will
    else
      -100 * this.will / this.wont
  
    
  // TODO: other methods missing
  
}
