package o1.takiainen

import o1._

object Takiaisohjelma2 extends App {

  
}