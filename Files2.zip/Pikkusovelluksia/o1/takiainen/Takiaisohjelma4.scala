package o1.takiainen

import o1._

object Takiaisohjelma4 extends App {

  
}