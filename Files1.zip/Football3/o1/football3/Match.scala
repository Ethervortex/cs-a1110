package o1.football3

import scala.collection.mutable.Buffer



class Match(val home: Club, val away: Club) {

  private val homeScorers = Buffer[Player]()    // container: goalscorers of the home team are added here
  private val awayScorers = Buffer[Player]()    // container: goalscorers of the away team are added here

  private val homeScorerNames = Buffer[String]()
  private val awayScorerNames = Buffer[String]()
  
  def winnerName = { 
    if (this.goalDifference < 0)
      this.away.name
    else if (this.goalDifference > 0)
      this.home.name
    else  
      "no winner" 
  }
  
  def winner: Option[Club] = {
    if (this.goalDifference < 0)
      Some(this.away)
    else if (this.goalDifference > 0)
      Some(this.home)
    else  
      None
  }
  
  def winningScorer: Option[Player] = {
    if (isHomeWin) {
      Some(this.homeScorers(this.awayScorers.size))
    }
    else if (isAwayWin) {
      Some(this.awayScorers(this.homeScorers.size))
    }
    else {
      None
    }
  }

/*  def winningScorerName = {

    if (isHomeWin) {
      this.homeScorerNames(this.awayScorerNames.size).toString
    }
    else if (isAwayWin) {
      this.awayScorerNames(this.homeScorerNames.size).toString
    }
    else {
      "no winning goal"
    }
  }*/
    
  def addGoal(scorer: Player): Unit = {
    if (scorer.employer == this.home) {
      this.homeScorers += scorer
      this.homeScorerNames += scorer.name
    } 
    
    else {
      this.awayScorers += scorer
      this.awayScorerNames += scorer.name
    }
  }
  
  def allScorers = this.homeScorers.toVector ++ this.awayScorers.toVector
    
    
  def hasScorer(possibleScorer: Player) = this.allScorers.contains(possibleScorer)
  
  
    
  def homeGoals = this.homeScorers.size
  
  def awayGoals = this.awayScorers.size  
  
  def totalGoals = this.homeScorers.size + this.awayScorers.size
  
  def isGoalless = if (this.totalGoals > 0) false else true
  
  def isHomeWin = if (this.homeGoals > this.awayGoals) true else false
  
  def isAwayWin = if (this.homeGoals < this.awayGoals) true else false
  
  def isTied = this.homeGoals == this.awayGoals
  
  def location = this.home.stadium
  
  def isHigherScoringThan(anotherMatch: Match) = this.totalGoals > anotherMatch.totalGoals
  
  def goalDifference = this.homeGoals - this.awayGoals
  
  
  
  override def toString = {
    //this.home + " vs. " + this.away + " at " + this.home.stadium + ": " +
    
    if (this.isGoalless) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + "tied at nil-nil"
    }
    else if (this.isTied && !this.isGoalless) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + "tied at " + this.homeGoals + "-all"
    }
    else if (this.isHomeWin) {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + this.homeGoals + "-" + this.awayGoals + " to " + this.home.name
    }
    else /*if (this.isAwayWin)*/ {
      this.home.name + " vs. " + this.away.name + " at " + this.home.stadium + ": " + this.awayGoals + "-" + this.homeGoals + " to " + this.away.name
    }

  }
}
