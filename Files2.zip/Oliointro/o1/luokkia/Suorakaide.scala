package o1.luokkia
import o1._

// Tämä luokka liittyy lukuun 2.4 ja on esitelty siellä. 

class Suorakaide(val sivu1: Double, val sivu2: Double) {

  //val sivu1 = annettuSivunPituus
  //val sivu2 = annettuToinenSivunPituus

  def ala = this.sivu1 * this.sivu2

  // jne. (Täällä voisi olla muita metodeita.)

}
