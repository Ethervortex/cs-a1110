package o1.odds

// This program is developed in Chapters 2.7 and 3.3.
// It creates a single Odds object and uses some of its methods.

import scala.io.StdIn._

object OddsTest1 extends App {
  
  println("Please enter the odds of an event as two integers on separate lines.")
  println("For instance, to enter the odds 5/1 (one in six chance of happening), write 5 and 1 on separate lines.")
  val firstInput = readInt()
  val secondInput = readInt() 
  val eka = new Odds(firstInput, secondInput)
  println("The odds you entered are:")
  println("In fractional format: " + eka.fractional)
  println("In decimal format: " + eka.decimal)
  println("In moneyline format: " + eka.moneyline)
  println("Event probability: " + eka.probability)
  println("Reverse odds: " + eka.not)
  println("Odds of happening twice: " + eka.both(eka)) 

  println("Please enter the size of a bet:")
  val thirdInput = readDouble()
  println("If successful, the bettor would claim " + eka.winnings(thirdInput))
  println("Please enter the odds of a second event as two integers on separate lines.")
  val fourthInput = readInt()
  val fifthInput = readInt()
  val toka = new Odds(fourthInput, fifthInput)
  println("The odds of both events happening are: " + eka.both(toka))
  
  println("The odds of one or both happening are: " + eka.either(toka))
}
