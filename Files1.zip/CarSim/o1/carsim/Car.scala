package o1.carsim
import o1.Pos


class Car(val fuelConsumption: Double, val tankSize: Double, initialFuel: Double, initialLocation: Pos) {
  
  private var currentLocation = initialLocation
  
  private var currentFuel = initialFuel
  
  private var currentDriven = 0.0
  
  //private var addFuel: Double = 0.0
  
  def location: Pos = this.currentLocation
 
  def fuel(toBeAdded: Double): Double = {
    // TODO: replace ??? with a working implementation
    var addFuel = 0.0
    
    if (this.tankSize > (this.currentFuel + toBeAdded)) {
      this.currentFuel = this.currentFuel + toBeAdded
      addFuel = toBeAdded
    }  
    else {
      addFuel = this.tankSize - this.currentFuel
      this.currentFuel = this.tankSize
    }
    addFuel
  }
  
  def fuel(): Double = this.fuel(999999)                                              
  
  def fuelRatio: Double = 100 * (this.currentFuel / this.tankSize)
    
  def metersDriven: Double = this.currentDriven // TODO: replace ??? with a working implementation

  def fuelRange: Double = this.currentFuel / this.fuelConsumption * 100000.0
  
  def drive(destination: Pos, metersToDestination: Double): Unit = {
    // TODO: replace ??? with a working implementation
    
    var positio = this.currentLocation
    
    if (this.fuelRange > metersToDestination) {
      this.currentLocation = destination
      this.currentDriven = this.currentDriven + metersToDestination
      this.currentFuel = this.currentFuel - (metersToDestination * this.fuelConsumption) / 100000.0
      
    }
    else {
      positio = this.currentLocation.add(((this.currentLocation)*(this.fuelRange/metersToDestination)).vectorTo(destination*(this.fuelRange/metersToDestination)))
      this.currentLocation = positio
      this.currentDriven = this.currentDriven + this.fuelRange
      this.currentFuel = 0.0
    }
  }
  
}

