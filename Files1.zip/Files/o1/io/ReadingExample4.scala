package o1.io

import scala.io.Source
import o1.play

// This program is introduced in Chapter 11.2.

object ReadingExample4 extends App {

  val file = Source.fromFile("running_up_that_hill.txt")

  try {
    val entireContents = file.mkString
    play(entireContents)
  } finally {
    file.close()
  }
  
}