package o1.robots

import o1._
import o1.CompassDir
import scala.util.Random

class Staggerbot(name: String, body: RobotBody, randomSeed: Int) extends RobotBrain(name, body) {
  private val directions = Vector[CompassDir](North, East, South, West)
  private val generaattori = new Random(randomSeed)
  
  private def randomDir: CompassDir = directions(this.generaattori.nextInt(4))
  
  def moveBody() = {
    val ekaSuunta = randomDir
    var occupant: Option[RobotBody] = None
    
    body.spinTowards(ekaSuunta)
    if(this.body.neighboringSquare(ekaSuunta).robot == None && this.body.neighboringSquare(ekaSuunta) != Wall) {
      this.body.moveTowards(ekaSuunta)
      body.spinTowards(randomDir)
    }
    else if(this.body.neighboringSquare(ekaSuunta) == Wall) {
      this.body.moveTowards(ekaSuunta)
    }
    else {
      occupant = this.body.neighboringSquare(ekaSuunta).robot
      occupant.foreach(_.destroy)
    }
  }
}


