package o1.robots

import o1._

class Nosebot(name: String, body: RobotBody) extends RobotBrain(name, body) {
  private val directions = Vector[CompassDir](North, East, South, West)
    
  def attemptMove(): Boolean = {
    
/*    if(this.squareInFront.isEmpty && !this.body.isStuck) {
      this.moveCarefully()
      true
    }
    else if(!isFull) { // if(!this.body.isStuck)
      this.body.spinClockwise()
      false
    }
    else
      false */
    
    if(this.squareInFront.isEmpty) {
      this.moveCarefully()
      true
    }
    else {
      this.body.spinClockwise()
      false
    }
      
  }
  
  def moveBody() = {
    var count = 0
    var isFull: Boolean = directions.forall(n => !body.neighboringSquare(n).isEmpty) // true jos kaikissa seinä tai botti
    
    //println(!isFull)
 /*   while(!this.body.isStuck && !this.attemptMove && count < 4) {
      count += 1
    } */
    
    while(!this.body.isStuck && !isFull && !this.attemptMove && count < 4) {
      count += 1
    }
  }
}


