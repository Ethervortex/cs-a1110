package o1.flappy

import o1._

// Define class Bug here.

class Bug(initialPos: Pos) {
  val radius = BugRadius
  
  private var currentPos = initialPos
  
  def pos = this.currentPos
  
  private var yVelocity = 0.0
  
  def move(siirto: Double) = {
    this.currentPos = this.currentPos.addY(siirto).clampY(0, 350)
  }
  
  def flap(isku: Double) = {
    yVelocity = -isku
    //move(-isku)
    //this.pos = this.pos.addY(-isku)
  }
  
  def fall() = {
    if (this.currentPos.y < 350) {
      yVelocity = yVelocity + FallingSpeed
    }
    move(yVelocity)
    //this.pos = this.pos.addY(FallingSpeed)
  }
  
  def isInBounds() = {
    if (this.pos.y > 0 && this.pos.y < GroundY)
      true
    else
      false
  }
  
  override def toString = "center at " + this.pos + ", radius " + BugRadius
}