package o1.election

import scala.collection.mutable.Buffer


class District(val name: String, val seats: Int, val candidates: Vector[Candidate]) {
  
  override def toString = this.name + ": " + this.candidates.size + " candidates, " + this.seats + " seats"
  
  def printCandidates() = {
  //  for (current <- this.candidates)
  //    println(current.toString)
    this.candidates.foreach(n => println(n.toString))
  }
  
  def candidatesFrom(party: String): Vector[Candidate] = {
//    val ehdokkaat = Buffer[Candidate]()
//    for (current <- this.candidates) {
//      if (current.party == party) { // Some(party)?
//        ehdokkaat += current
//      }
//    }
    this.candidates.filter(_.party == party)
//    ehdokkaat.toVector
  }
  
  def topCandidate: Candidate = {
    /*var aaniharava = this.candidates(0)
    for (current <- this.candidates) {
      if (current.>(aaniharava)) {
        aaniharava = current
      }
    }
    aaniharava */
    this.candidates.maxBy(_.votes)
  }
  
  def totalVotes: Int = {
/*    var totalSoFar = 0
    for (current <- this.candidates) {
      totalSoFar += current.votes
    }
    totalSoFar */
    this.candidates.foldLeft(0)( _ + _.votes )
  }
  
  def totalVotes(party: String): Int = {
/*    var totalSoFar = 0
    for (current <- this.candidates) {
      if (current.party == party) {
        totalSoFar += current.votes
      }
    }
    totalSoFar */
    this.candidates.foldLeft(0)( (sum, n) => if (n.party == party) sum + n.votes else sum )
  }
  
  def candidatesByParty: Map[String, Vector[Candidate]] = {
    var puolue = this.candidates.groupBy(_.party)
    puolue
  }
  
  def topCandidatesByParty: Map[String, Candidate] = {
    //val top = this.candidatesByParty.values.maxBy(_.votes)
    //val top = this.candidates.map( cand => cand.party -> cand).toMap //.maxBy(_.votes)
    val allCand = candidatesByParty.toVector
    var top = Buffer[Candidate]()
    val puolue = Buffer[String]()
    for (pari <- allCand) {
      top += pari._2.maxBy(_.votes)
      puolue += pari._1
    }
    puolue.toVector.zip(top.toVector).toMap
  }
  
  def votesByParty: Map[String, Int] = {
    val allCand = candidatesByParty.toVector
    var aanet = Buffer[Int]()
    val puolue = Buffer[String]()
    for (pari <- allCand) {
      aanet += pari._2.foldLeft(0)( (sum, next) => sum + next.votes)
      puolue += pari._1
    }
    puolue.toVector.zip(aanet.toVector).toMap
  }
  
  def rankingsWithinParties: Map[String, Vector[Candidate]] = {
    val allCand = candidatesByParty.toVector
    var cand = Buffer[Vector[Candidate]]()
    val puolue = Buffer[String]()
    for (pari <- allCand) {
      cand += pari._2.sortBy(-_.votes)
      puolue += pari._1
    }
    puolue.toVector.zip(cand.toVector).toMap
  }
  
  def rankingOfParties: Vector[String] = {
    val aanet = votesByParty.toVector.sortBy(-_._2)
    aanet.unzip._1
  }
  
  def distributionFigures: Map[Candidate, Double] = {
    //val partyVotes = votesByParty.toVector
    val rank = rankingsWithinParties.toVector
    var aanet = 0.0
    var vertailuluku = 0.0
    var laskuri = 0
    var distLuku = Buffer[(Candidate, Double)]()
    
    for( (puolue, kandidaatti) <- rank) {
      aanet = totalVotes(puolue).toDouble
      laskuri = 0
      for ( kand <- kandidaatti) {
        laskuri += 1
        vertailuluku = aanet / laskuri
        distLuku +=  kand -> vertailuluku 
      }
    }
    distLuku.toMap
  }
  
  def electedCandidates: Vector[Candidate] = {
    val allCand = distributionFigures.toVector.sortBy(-_._2)
    allCand.unzip._1.take(seats)
  }
}